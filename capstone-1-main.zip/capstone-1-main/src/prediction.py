import mlflow.sklearn
import pandas as pd
import os

model_uri = "../deployment/model"

loaded_model = mlflow.sklearn.load_model(model_uri)

print("MLFlow Model Loaded Successfully")

test_df = pd.DataFrame({
    "Amount": [250000.0],
    "Payment_currency": [2],
    "Received_currency": [1],
    "Sender_bank_location": [5],
    "Receiver_bank_location": [7],
    "Payment_type": [3],
    "Laundering_type": [1]
})

prediction = loaded_model.predict(test_df)

print(f"Prediction: {prediction[0]}")