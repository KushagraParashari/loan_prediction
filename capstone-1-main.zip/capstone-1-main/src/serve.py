
import os
import glob
import pandas as pd
import numpy as np
import mlflow.sklearn

 
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
 
app = FastAPI(title="Prediction API",version="1.0")
 
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.abspath(
    os.path.join(BASE_DIR, "../deployment/model")
)
 
model_files = glob.glob(
    os.path.join(MODEL_DIR, "**", "MLmodel"),
    recursive=True
)
 
if not model_files:
    raise FileNotFoundError(
        f"No MLflow model found in: {MODEL_DIR}"
    )
 
model_path = os.path.dirname(model_files[0])
model = mlflow.sklearn.load_model(model_path)
 
print("Model loaded:", model_path)
 
 
class PredictionRequest(BaseModel):
    amount: float = Field(alias="Amount")
    payment_currency: int = Field(alias="Payment_currency")
    received_currency: int = Field(alias="Received_currency")
    sender_bank_location: int = Field(alias="Sender_bank_location")
    receiver_bank_location: int = Field(alias="Receiver_bank_location")
    payment_type: int = Field(alias="Payment_type")
    Laundering_type: int = Field(alias="Laundering_type")

 
 
@app.get("/")
def home():
    return {"message": "Prediction API is running"}
 
 
@app.get("/laundering")
def health():
    return {"status": "laundrying", "model_loaded": model is not None}
 
 
@app.post("/predict")
def predict(request: PredictionRequest):
    try:
        df = pd.DataFrame([request.dict()])
        predictions = model.predict(df)
 
        return {
            "predictions": predictions.tolist()
        }
 
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e)
        )
 
 
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
 







