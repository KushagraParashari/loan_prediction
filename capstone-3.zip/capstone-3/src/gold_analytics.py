from pyspark.sql.functions import *
from config import (
    gold_daily_path,
    gold_vehicle_path,
    gold_location_path,
    gold_payment_path,
    gold_cancellation_path
)

def get_gold_metrics(spark):

    daily_df = spark.read.format("delta").load(gold_daily_path)

    vehicle_df = spark.read.format("delta").load(gold_vehicle_path)

    location_df = spark.read.format("delta").load(gold_location_path)

    payment_df = spark.read.format("delta").load(gold_payment_path)

    cancellation_df = spark.read.format("delta").load(gold_cancellation_path)

    # Overall business KPIs
    overall = daily_df.agg(
        sum("total_bookings").alias("total_bookings"),
        sum("total_revenue").alias("total_revenue")
    ).first().asDict()

    if overall["total_bookings"]:
        overall["average_booking_value"] = (
            overall["total_revenue"] /
            overall["total_bookings"]
        )
    else:
        overall["average_booking_value"] = None

    # Top Pickup Locations
    top_locations = [
        row.asDict()
        for row in location_df
            .orderBy(desc("total_bookings"))
            .limit(10)
            .collect()
    ]

    # Vehicle Type Summary
    vehicle_summary = [
        row.asDict()
        for row in vehicle_df
            .orderBy(desc("total_bookings"))
            .collect()
    ]

    # Payment Method Summary
    payment_summary = [
        row.asDict()
        for row in payment_df
            .orderBy(desc("revenue"))
            .collect()
    ]

    # Booking Status Summary
    cancellation_summary = [
        row.asDict()
        for row in cancellation_df.collect()
    ]

    return {
        "overall": overall,
        "top_locations": top_locations,
        "vehicle_summary": vehicle_summary,
        "payment_summary": payment_summary,
        "cancellation_summary": cancellation_summary
    }