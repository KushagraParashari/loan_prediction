import streamlit as st
import requests
 
API_URL = "http://127.0.0.1:8000/ask"
 
st.set_page_config(
    page_title="Customer Support Agentic RAG",
    layout="wide"
)
 
st.title("Customer Support Agentic RAG System")
st.markdown("Ask customer support questions using RAG + Google-Search + OpenAI")
 
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
 
user_query = st.text_input(
    "Enter your query"
)
 
if st.button("Ask Question"):
 
    if user_query.strip() == "":
        st.warning("Please enter a question")
 
    else:
 
        with st.spinner("Generating response..."):
 
            try:
 
                response = requests.post(
                    API_URL,
                    json={
                        "query": user_query
                    }
                )
 
                result = response.json()
 
                answer = result.get(
                    "answer",
                    "No response generated"
                )
 
                st.session_state.chat_history.append(
                    {
                        "question": user_query,
                        "answer": answer
                    }
                )
 
            except Exception as e:
                st.error(str(e))
 
st.divider()
 
for chat in reversed(st.session_state.chat_history):
 
    st.markdown(f"### 👨 User")
    st.write(chat["question"])
 
    st.markdown(f"### 🤖 Customer Support Assistant")
    st.write(chat["answer"])
 
    st.divider()
