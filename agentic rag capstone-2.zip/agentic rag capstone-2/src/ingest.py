# 1. Import Library
from langchain_community.document_loaders import JSONLoader, CSVLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS
#from langchain.embeddings import OpenAIEmbeddings
from langchain_openai import AzureOpenAIEmbeddings
from dotenv import load_dotenv
import os
 
load_dotenv()
 

 
# 2. Load JSON and CSV files from Data Directory and create document
 
jq_schema = ".[] | {instruction: .instruction, input: .input, output: .output}"
 

 
csv_loader = CSVLoader(file_path="./data/customer_support_tickets.csv",
                       csv_args={"delimiter": ","})
 
medical_csv_documents = csv_loader.load()
 
medical_docs = medical_csv_documents
 
# 3. Split the documents into chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000,
                                               chunk_overlap=100,
                                               separators=["\n\n", "\n", " ", ""])
 
customer_chunks = text_splitter.split_documents(medical_docs)
 
# 4. Create embeddings and store them in FAISS vectorstore
#from langchain_openai import OpenAIEmbeddings
embeddings = AzureOpenAIEmbeddings(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    azure_deployment="text-embedding-ada-002-3"  # replace with actual deployment name
)
customer_vectorstore = FAISS.from_documents(customer_chunks, embeddings)

# 5. Save the vectorstore to disk
customer_vectorstore.save_local("faiss_index")
 
print("Vectorstore created and saved successfully.")

