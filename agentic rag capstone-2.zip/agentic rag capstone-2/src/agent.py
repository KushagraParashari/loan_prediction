# Single Agent with Multi-Tool = serpapi, youtube, rag
from langchain.agents import initialize_agent, AgentType, create_tool_calling_agent, AgentExecutor
from langchain.tools import Tool
from langchain.utilities import SerpAPIWrapper
#from langchain_community.tools import YouTubeSearchTool
from src.rag import load_pipeline, ask_question
#from langchain_community.tools import YouTubeSearchTool
import os
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_community.utilities import WikipediaAPIWrapper

# load the rag pipeline
rag_chain = load_pipeline()
load_dotenv()

def customer_rag_tool_func(question: str) -> str:
    try:
        result = ask_question(rag_chain,question)
        answer = result.get("answer","Not found in the context.")
        return answer
    except Exception as e:
        return f"Error occurred while processing the question: {str(e)}"

 
customer_rag_tool = Tool(
    name="ChatDoctor-RAG",
    func=customer_rag_tool_func,
    description=(
       "An intelligent customer support knowledge retrieval tool that searches "
        "historical support tickets using Retrieval-Augmented Generation (RAG). "
        "Use this tool to find resolutions for customer complaints, technical issues, "
        "billing disputes, account access problems, product-related questions, "
        "service requests, and support-related inquiries. The tool analyzes ticket "
        "subjects, descriptions, issue categories, priority levels, support channels, "
        "resolution history, assigned agents, and customer satisfaction ratings to "
        "retrieve relevant past cases and provide context-aware answers. Use this "
        "tool whenever a user asks about customer support issues, troubleshooting "
        "steps, common resolutions, ticket status patterns, or historical support "
        "experiences."
    )
)
 
search = SerpAPIWrapper()
 
search_tool = Tool(
    name="web-search",
    func=search.run,
    description=("A web search tool that retrieves current and publicly available information "
        "from the internet. Use this tool only when the requested information is not "
        "found in the Customer Support RAG knowledge base or when the user explicitly "
        "requests recent, live, or external information. Useful for company websites, "
        "product documentation, software updates, policy changes, service status, "
        "troubleshooting guides, and recent announcements. Do not use this tool for "
        "questions that can be answered using historical customer support tickets. "
        "Always attempt Customer-Support-RAG first before using web search."
    )
)
 

wikipedia = WikipediaAPIWrapper(
    top_k_results=3,
    doc_content_chars_max=2000
)
wikipedia_tool = Tool(
    name="wikipedia-search",
    func=wikipedia.run,
    description=(
        "Searches Wikipedia for factual and encyclopedic information. "
        "Use this tool when the user asks for definitions, concepts, "
        "background information, historical events, companies, technologies, "
        "products, industry terminology, or general knowledge that may not be "
        "available in the Customer Support RAG knowledge base. "
        "Useful for understanding technical concepts, product categories, "
        "business terms, and educational information. "
        "Input should be a clear and concise search query."
    )
)

# Initialize LLM
llm = ChatOpenAI(
    base_url=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    model="gpt-5-mini"
)
 
# initialize the agent
agent = initialize_agent(
    tools = [customer_rag_tool, search_tool, wikipedia_tool],
    llm = llm,
    agent = AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose = True,
    max_iterations = 5,
    early_stopping_method = "generate",
    handle_parsing_errors = True
)

def ask_agent(question: str):
    result = agent.invoke({"input": question})
    return result["output"]
