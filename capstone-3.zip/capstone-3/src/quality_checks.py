from pyspark.sql.functions import *
from config import silver_path

def run_quality_checks(spark):

    df = spark.read.format("delta").load(silver_path)

    row_count = df.count()

    required_columns = [
        "Booking ID",
        "Booking Status",
        "Customer ID",
        "Vehicle Type",
        "Pickup Location",
        "Drop Location",
        "Booking Value",
        "Ride Distance",
        "Payment Method"
    ]

    null_counts = (
        df.select([
            count(when(col(c).isNull(), 1)).alias(c)
            for c in required_columns
        ])
        .first()
        .asDict()
    )

    invalid_booking_value = (
        df.filter(
            col("Booking Value").isNull() |
            (col("Booking Value") <= 0)
        ).count()
    )

    invalid_distance = (
        df.filter(
            col("Ride Distance").isNull() |
            (col("Ride Distance") <= 0)
        ).count()
    )

    invalid_driver_rating = (
        df.filter(
            (col("Driver Ratings") < 0) |
            (col("Driver Ratings") > 5)
        ).count()
    )

    invalid_customer_rating = (
        df.filter(
            (col("Customer Rating") < 0) |
            (col("Customer Rating") > 5)
        ).count()
    )

    duplicate_bookings = (
        df.groupBy("Booking ID")
        .count()
        .filter(col("count") > 1)
        .count()
    )

    passed = (
        row_count > 0
        and all(v == 0 for v in null_counts.values())
        and invalid_booking_value == 0
        and invalid_distance == 0
        and invalid_driver_rating == 0
        and invalid_customer_rating == 0
        and duplicate_bookings == 0
    )

    return {
        "status": "passed" if passed else "failed",
        "row_count": row_count,
        "null_counts": null_counts,
        "invalid_booking_value": invalid_booking_value,
        "invalid_distance": invalid_distance,
        "invalid_driver_rating": invalid_driver_rating,
        "invalid_customer_rating": invalid_customer_rating,
        "duplicate_bookings": duplicate_bookings
    }