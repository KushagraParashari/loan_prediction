'''
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential

ml_client = MLClient(
    DefaultAzureCredential(),
    subscription_id = "18da8d4a-c01d-4c15-bc83-18545261810a",
    resource_group_name = "rg-chrurn-mlops",
    workspace_name = "mlflow-workspace"
)

print("Connected to Azure ML Workspace")

DATA_PATH = "../data/Telco_Customer_Churn.csv"
ARTIFACT_DIR = "../artifacts"

import os
 
DATA_PATH = "../data/Telco_Customer_Churn.csv"
ARTIFACT_DIR = "../artifacts"
 
MODEL_DIR = os.path.join(ARTIFACT_DIR, "model")
METRICS_DIR = os.path.join(ARTIFACT_DIR, "metrics")
PREDICTIONS_DIR = os.path.join(ARTIFACT_DIR, "predictions")
 
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(METRICS_DIR, exist_ok=True)
os.makedirs(PREDICTIONS_DIR, exist_ok=True)
 
print(DATA_PATH)
 
import json
import joblib
import warnings
 
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
 
import mlflow
import mlflow.sklearn
 
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
 
warnings.filterwarnings('ignore')

telco_df = pd.read_csv(DATA_PATH)

telco_df.info()

display(telco_df.describe(include = 'all'))

display(telco_df.duplicated().sum())

telco_df.isnull().sum()

telco_df['TotalCharges'].replace(' ', np.nan, inplace = True)

telco_df.dropna(inplace = True)

# Clean up TotalCharges
telco_df['TotalCharges'] = pd.to_numeric(
    telco_df['TotalCharges'],
    errors = 'coerce'
)

print(telco_df['TotalCharges'].dtype)

# Value counts of 'Churn'
telco_df['Churn'].value_counts()

telco_df.drop('customerID', axis = 1, inplace = True)

X = telco_df.drop('Churn', axis = 1)
Y = telco_df['Churn']

numerical_features = X.select_dtypes(
    include = ['int64', "float64"]
).columns.tolist()

categorical_features = X.select_dtypes(
    include = ["object"]
).columns.tolist()

print("Numerical Features:", numerical_features)
print("Categorical Features:", categorical_features)

x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size = 0.2, random_state = 2, stratify = Y)

numerical_pipeline = Pipeline(
    steps = [
        ("inputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
 
categorical_pipeline = Pipeline(
    steps = [
        ("inputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore"))
    ])

preprocessor = ColumnTransformer(
    transformers = [("num", numerical_pipeline, numerical_features),
    ("cat", categorical_pipeline, categorical_features)]
)

logit_model = LogisticRegression(solver='lbfgs', max_iter = 10000, C = 1,
                                 penalty = 'l2')

pipeline = Pipeline(steps = [("preprocessor", preprocessor),
                    ("model", logit_model)])

pipeline.fit(x_train, y_train)

ypred = pipeline.predict(x_test)

ypred_prob = pipeline.predict_proba(x_test)[:,  1]

pipeline.score(x_test, y_test)

from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, precision_score, recall_score, f1_score, roc_auc_score
 
accuracy = accuracy_score(y_test, ypred)
precision = precision_score(y_test, ypred, pos_label="Yes")
recall = recall_score(y_test, ypred, pos_label="Yes")
f1 = f1_score(y_test, ypred, pos_label="Yes")
 
roc_auc = roc_auc_score(
    y_test,
    pipeline.predict_proba(x_test)[:, 1]
)
 
metrics = {
    "accuracy": accuracy,
    "precision": precision,
    "recall": recall,
    "f1_score": f1,
    "roc_auc": roc_auc
}
 

metrics_df = pd.DataFrame(metrics.items(), columns = ["Metric","Value"])

print(classification_report(y_test, ypred, target_names = ["No Churn","Churn"]))
 
metrics_path = os.path.join(METRICS_DIR, "metrics.json")
 
with open(metrics_path, "w") as file:
    json.dump(metrics, file, indent = 4)

# save the predictions
predictions = x_test.copy()
predictions['actual_churn'] = y_test.values
predictions['prediction_churn'] = ypred
predictions['churn_probability'] = ypred_prob
 
prediction_path = os.path.join(PREDICTIONS_DIR, "test_prediction.csv")
predictions.to_csv(prediction_path, index = False)
 
print(prediction_path)

joblib.dump(pipeline,
            os.path.join(MODEL_DIR, "churn_model.pkl"))

workspace = ml_client.workspaces.get(
    ml_client.workspace_name
)

EXPERIMENT_NAME = "telco-churn-mlflow"
 
mlflow.set_experiment(EXPERIMENT_NAME)
 
print("Experiment: ", EXPERIMENT_NAME)

local_model_path = os.path.join(MODEL_DIR, "churn_model.pkl")
 
with mlflow.start_run() as run:
 
    run_id = run.info.run_id
    print("Run ID:", run_id)
 
    pipeline.fit(x_train, y_train)
 
    ypred = pipeline.predict(x_test)
    ypred_prob = pipeline.predict_proba(x_test)[:, 1]
 
    accuracy = accuracy_score(y_test, ypred)
    precision = precision_score(y_test, ypred, pos_label="Yes")
    recall = recall_score(y_test, ypred, pos_label="Yes")
    f1 = f1_score(y_test, ypred, pos_label="Yes")
 
    roc_auc = roc_auc_score(
        y_test,
        ypred_prob
    )
 
    mlflow.log_param("model_type", "LogisticRegression")
    mlflow.log_param("test_size", 0.20)
    mlflow.log_param("random_state", 2)
 
    mlflow.log_metric("accuracy", accuracy)
    mlflow.log_metric("precision", precision)
    mlflow.log_metric("recall", recall)
    mlflow.log_metric("f1_score", f1)
    mlflow.log_metric("roc_auc", roc_auc)
 
    joblib.dump(
        pipeline,
        local_model_path
    )
 
    mlflow.log_artifact(
        metrics_path,
        artifact_path="metrics"
    )
 
    mlflow.log_artifact(
        prediction_path,
        artifact_path="predictions"
    )
 
    mlflow.log_artifact(
        local_model_path,
        artifact_path="model"
    )
 
    print("MLflow Run Completed")

# Get Model URI
model_uri = f"runs:/{run_id}/model"
print(model_uri)
 

import os
import shutil
import pickle
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import mlflow
import mlflow.sklearn
 
 
local_model_path = os.path.join(MODEL_DIR, "churn_model.pkl")
local_save_dir = os.path.join(MODEL_DIR, "final_model_asset")
 
with mlflow.start_run() as run:
    run_id = run.info.run_id
    print("Run ID:", run_id)
   
   
    pipeline.fit(x_train, y_train)
 
    # Array mapping targets fetch karna
    ypred = pipeline.predict(x_test)
    ypred_prob = pipeline.predict_proba(x_test)[:, 1]
 
   
    y_test_numeric = np.where(np.array(y_test) == 'Yes', 1, 0)
    ypred_numeric = np.where(np.array(ypred) == 'Yes', 1, 0)
   
    accuracy = accuracy_score(y_test_numeric, ypred_numeric)
    precision = precision_score(y_test_numeric, ypred_numeric, pos_label=1)
    recall = recall_score(y_test_numeric, ypred_numeric, pos_label=1)
    f1 = f1_score(y_test_numeric, ypred_numeric, pos_label=1)
    roc_auc = roc_auc_score(y_test_numeric, ypred_prob) # Robust tracking using probabilities
 
   
    mlflow.log_param("model_type", "LogisticRegression")
    mlflow.log_param("test_size", 0.20)
    mlflow.log_param("random_state", 2)
   
    mlflow.log_metric("accuracy", accuracy)
    mlflow.log_metric("precision", precision)
    mlflow.log_metric("recall", recall)
    mlflow.log_metric("f1_Score", f1)
    mlflow.log_metric("roc_auc", roc_auc)
 
    # Artifact logs path mapping tracking
    mlflow.log_artifact(metrics_path, artifact_path="metrics")
    mlflow.log_artifact(prediction_path, artifact_path="predictions")
 
   
    if os.path.exists(local_save_dir):
        shutil.rmtree(local_save_dir)
       
   
    mlflow.sklearn.save_model(
        sk_model=pipeline,
        path=local_save_dir,
        skops_trusted_types=["numpy.dtype"] # Security engine verification block bypass
    )
   
   
    mlflow.log_artifacts(
        local_dir=local_save_dir,
        artifact_path="model"
    )
     
    shutil.rmtree(local_save_dir)
 
    print("ML Model Saved Successfully!")

# Get Model URI
model_uri = f"runs:/{run_id}/model"
print(model_uri)

# Load the Model from MLFLow
loaded_model = mlflow.sklearn.load_model(model_uri)
 
print("MLFlow Model Loaded Successfully")

#register the model
from azure.ai.ml.entities import Model
 
REGISTERED_MODEL_NAME = "telco-churn-mlflow"
 
registered_model = ml_client.models.create_or_update(
    Model(
        name=REGISTERED_MODEL_NAME,
        path=model_uri,
        type="mlflow_model"
    )
)
 
print("Registered model:")
print(registered_model.name)
print("Version:")
print(registered_model.version)

MODEL_VERSION = registered_model.version
 
print(
    "Model:",
    REGISTERED_MODEL_NAME
)
 
print(
    "Version:",
    MODEL_VERSION
)

model = ml_client.models.get(
    name = REGISTERED_MODEL_NAME,
    version=MODEL_VERSION
)
 
print("Model Name:", model.name)
print("Model Version:",model.version)
print("Model Type:",model.type)

#end point
!pip install uuid
import uuid
from azure.ai.ml.entities import ManagedOnlineEndpoint
 
endpoint_name = ("telco-churn-" +
                 str(uuid.uuid4())[:8])
 
endpoint = ManagedOnlineEndpoint(
    name = endpoint_name,
    description = "Telco Customer Churn Prediction Endpoint",
    auth_mode = "key"
)
 
print("Endpoint :", endpoint_name)

endpoint_result = ml_client.begin_create_or_update(
    endpoint
).result()
 
print(
    "Endpoint created:"
)
 
print(
    endpoint_result.name
)

import os
model_dir = os.path.abspath("../deployment/model")
os.makedirs(model_dir, exist_ok=True)
 
ml_client.models.download(
    name=registered_model.name,
    version=registered_model.version,
    download_path=model_dir
)
 
print("Model downloaded to:", model_dir)
'''
