# FastAPI
from fastapi import FastAPI
from pydantic import BaseModel, Field
from src.agent import ask_agent
 
app = FastAPI(
    title = "Agentic RAG API",
    version="1.0",
    description="Agetic RAG with google search and youtube search agents."
)
 
class QueryRequest(BaseModel):
    question: str = Field(
        ...,
        description="user Question"
    )
 
@app.get("/")
def home():
    return {
        "message": "Agentic RAG API is Running"
    }
 
@app.get("/health")
def health():
    return {
        "status":"healthy"
    }
 
@app.post("/ask")
def ask(request: QueryRequest):
    answer = ask_agent(
        request.question
    )
    return {"answer": answer}
 
 