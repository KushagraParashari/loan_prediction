'''
storage_account_name = "write-your-storage-account"
container_name = "container-name"
# Paste your newly rotated storage key here.
storage_account_key = "storage-account-key"
'''
# Paste your Microsoft Foundry API key here.
foundry_api_key = "DfMULYeBl9bmMVhzDg27RoMNICVcEvQNtYSmUAx9gkZ0o4fWAMa4JQQJ99CJACYeBjFXJ3w3AAAAACOGTTFo"
foundry_endpoint = "https://azure-kp-01.services.ai.azure.com/api/projects/proj-default"
foundry_model = "gpt-5-mini"

storage_base = "file:/Workspace/project/capstone-3/data"

source_path = f"{storage_base}/raw-data/cab_booking.csv"

base_path = f"{storage_base}/output"

bronze_path = f"{base_path}/bronze"

silver_path = f"{base_path}/silver"

gold_daily_path = f"{base_path}/gold/daily_booking_summary"

gold_vehicle_path = f"{base_path}/gold/vehicle_summary"

gold_location_path = f"{base_path}/gold/location_summary"

gold_payment_path = f"{base_path}/gold/payment_summary"

gold_cancellation_path = f"{base_path}/gold/cancellation_summary"
# "/Workspace/green-taxi-agentic-etl/data"