import os
from dotenv import load_dotenv
from langchain.vectorstores import FAISS
from langchain_openai import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.memory import ConversationBufferMemory
from langchain_core.prompts import PromptTemplate
from langchain.chains import ConversationalRetrievalChain
from langchain_community.retrievers import BM25Retriever
from langchain.retrievers.contextual_compression import ContextualCompressionRetriever
from langchain_cohere import CohereRerank
from langchain_openai import AzureOpenAIEmbeddings
from langchain_openai import ChatOpenAI
load_dotenv()
 
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

 
def load_pipeline():
    # create openai embeddings
    embeddings = AzureOpenAIEmbeddings(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        azure_deployment="text-embedding-ada-002-3"  # replace with actual deployment name
)
    # create vector database
    faiss_store = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)
    llm = ChatOpenAI(
    base_url=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    model="gpt-5-mini"
)
    # add memory using ConversationBufferMemory
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True, output_key='answer')
 
    # semantic retriever
    semantic_retriever = faiss_store.as_retriever(search_type="mmr",
                                              search_kwargs={"k": 8})
    # create documents from vectorstore
    documents = list(faiss_store.docstore._dict.values())
    # keyword retriver
    bm25_retriever = BM25Retriever.from_documents(
        documents=documents, k=8)
 
    from langchain.retrievers import EnsembleRetriever
    # Hybrid Search - Ensemble Retriever
    ensemble_retriever = EnsembleRetriever(retrievers=[semantic_retriever,
                                                   bm25_retriever],
                                                   weights=[0.6, 0.4])
                                               
    reranker = CohereRerank(
    cohere_api_key=os.getenv("COHERE_API_KEY"),
    model="rerank-v3.5",
    top_n=4)                                            
 
    contexual_retriever = ContextualCompressionRetriever(
    base_compressor=reranker,
    base_retriever=ensemble_retriever)
   
    prompt = PromptTemplate(
    input_variables=["context", "chat_history", "question"],
    template="""
You are a Customer Support AI Assistant powered by a Retrieval-Augmented Generation (RAG) system.

Your role is to assist customers by retrieving and analyzing relevant historical support tickets from the knowledge base.

The knowledge base contains:
- Ticket_ID
- Ticket_Subject
- Ticket_Description
- Issue_Category
- Priority_Level
- Ticket_Channel
- Resolution_Time_Hours
- Assigned_Agent
- Satisfaction_Score

Instructions:
- Use only the information found in the retrieved context.
- Identify similar customer issues and their resolutions.
- Provide accurate, concise, and professional responses.
- Reference common troubleshooting steps when available.
- Do not invent solutions or policies.
- If the information is unavailable in the retrieved context, reply:
  "The answer is not available in the provided context."
- Maintain context from the conversation history when answering follow-up questions.

Retrieved Context:
{context}

Conversation History:
{chat_history}

Customer Question:
{question}

Response:
"""
    )
 
    # Conversational RAG Chain
    chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=contexual_retriever,
        memory=memory,
        return_source_documents=True,
        combine_docs_chain_kwargs={"prompt": prompt},
    )
    return chain
 
def ask_question(chain, question):
    start = time.time()
    result = chain.invoke({"question": question})
    latency = time.time() - start
    docs = result["source_documents"]
 
    retrieved_docs = [doc.page_content[:200] for doc in docs]
    sources = [doc.metadata for doc in docs]
 
    return {
        "answer": result["answer"],
        "retrieved_docs": retrieved_docs,
        "sources": sources,
        "latency": latency,
    }
 