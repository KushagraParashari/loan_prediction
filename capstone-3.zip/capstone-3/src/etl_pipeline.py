from pyspark.sql.functions import *
from config import (source_path, bronze_path, silver_path, gold_daily_path,
                    gold_location_path, gold_payment_path)

def read_source(spark):
    # spark.conf.set(f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net",storage_account_key)
    raw_df = spark.read.csv(source_path,header=True,inferSchema=True)
    return raw_df

def build_bronze(spark, raw_df):

    renamed_cols = [
        c.strip()
        .replace(" ", "_")
        .replace("/", "_")
        .replace("-", "_")
        .replace(".", "_")
        for c in raw_df.columns
    ]

    bronze_df = raw_df.toDF(*renamed_cols)

    bronze_df = bronze_df.withColumn(
        "ingestion_timestamp",
        current_timestamp()
    )

    bronze_df = bronze_df.coalesce(2)

    bronze_df.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(bronze_path)

    return spark.read.format("delta").load(bronze_path)

def build_silver(spark, bronze_df):
    silver_df = bronze_df.withColumn(
    "booking_timestamp",
    to_timestamp(
        concat_ws(" ", col("Date"), col("Time"))
    )
)


    # Remove duplicate records
    silver_df = silver_df.dropDuplicates()

    # Check null counts before applying data quality filters
    silver_df.select([count(when(col(c).isNull(), c)).alias(c) 
                      for c in silver_df.columns]).show()

    # Keep valid trip records
    silver_df = silver_df.filter(
        col("Booking Value") > 0
    )

    # Calculate trip duration before Gold aggregation
    silver_df = silver_df.withColumn(
        "Booking Status",
        trim(initcap(col("Booking_Status")))
    )
    
    silver_df = silver_df.withColumn(
        "Payment Method",
        trim(initcap(col("Payment_Method")))
    )
    silver_df = silver_df.withColumn(
        "booking_date",
        to_date("booking_timestamp")
    )

    silver_df = silver_df.withColumn(
        "booking_month",
        date_format(
            col("booking_timestamp"),
            "yyyy-MM"
        )
    )
    silver_df = silver_df.withColumn(
        "booking_hour",
        hour("booking_timestamp")
    )

    # Cancellation flag
    silver_df = silver_df.withColumn(
        "is_cancelled",
        when(
            col("Booking_Status").contains("Cancelled"),
            1
        ).otherwise(0)
    )

    # Completed flag
    silver_df = silver_df.withColumn(
        "is_completed",
        when(
            col("Booking_Status") == "Completed",
            1
        ).otherwise(0)
    )

    silver_df.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(silver_path)

    return spark.read.format("delta").load(silver_path)


def build_gold(spark, silver_df):

    daily_summary_df = (
        silver_df
        .groupBy("booking_date")
        .agg(
            count("*").alias("total_bookings"),
            sum("Booking_Value").alias("total_revenue"),
            avg("Booking_Value").alias("avg_booking_value"),
            avg("Ride_Distance").alias("avg_distance"),
            avg("Driver_Ratings").alias("avg_driver_rating"),
            avg("Customer_Rating").alias("avg_customer_rating")
        )
    )

    vehicle_summary_df = (
        silver_df
        .groupBy("Vehicle_Type")
        .agg(
            count("*").alias("total_bookings"),
            sum("Booking_Value").alias("revenue"),
            avg("Ride_Distance").alias("avg_distance")
        )
    )

    location_summary_df = (
        silver_df
        .groupBy("Pickup_Location")
        .agg(
            count("*").alias("total_bookings"),
            sum("Booking_Value").alias("revenue"),
            avg("Ride_Distance").alias("avg_distance")
        )
    )

    payment_summary_df = (
        silver_df
        .groupBy("Payment_Method")
        .agg(
            count("*").alias("total_bookings"),
            sum("Booking_Value").alias("revenue")
        )
    )

    cancellation_summary_df = (
        silver_df
        .groupBy("Booking_Status")
        .agg(
            count("*").alias("total_bookings")
        )
    )

    daily_summary_df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(gold_daily_path)

    vehicle_summary_df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(gold_vehicle_path)

    location_summary_df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(gold_location_path)

    payment_summary_df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(gold_payment_path)

    cancellation_summary_df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(gold_cancellation_path)

    return {
        "daily_summary": daily_summary_df,
        "vehicle_summary": vehicle_summary_df,
        "location_summary": location_summary_df,
        "payment_summary": payment_summary_df,
        "cancellation_summary": cancellation_summary_df
    }


def run_etl(spark):

    raw_df = read_source(spark)

    bronze_df = build_bronze(spark, raw_df)

    silver_df = build_silver(spark, bronze_df)

    gold_dfs = build_gold(spark, silver_df)

    result = {
        "status": "success",
        "bronze_rows": bronze_df.count(),
        "silver_rows": silver_df.count()
    }

    for name, df in gold_dfs.items():
        result[f"{name}_rows"] = df.count()

    return result