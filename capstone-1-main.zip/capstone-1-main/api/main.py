
import joblib
import pandas as pd

from fastapi import FastAPI
from fastapi.openapi.docs import get_swagger_ui_html
from pydantic import BaseModel, Field


app = FastAPI(
    title="Money Laundering Detection API",
    description="API for detecting suspicious financial transactions.",
    version="1.0"
)

# Load Model
model = joblib.load("./model/money_laundering_model.pkl")


class TransactionInput(BaseModel):

    amount: float = Field(alias="Amount")
    payment_currency: int = Field(alias="Payment_currency")
    received_currency: int = Field(alias="Received_currency")
    sender_bank_location: int = Field(alias="Sender_bank_location")
    receiver_bank_location: int = Field(alias="Receiver_bank_location")
    payment_type: int = Field(alias="Payment_type")
    Laundering_type: int = Field(alias="Laundering_type")


@app.get("/")
def home():

    return {
        "message": "Money Laundering Detection API"
    }


@app.get("/docs", include_in_schema=False)
def custom_docs():

    return get_swagger_ui_html(
        openapi_url="/openapi.json",
        title="Money Laundering Detection API"
    )


@app.post("/predict")
def predict(data: TransactionInput):

    input_data = pd.DataFrame([
        data.model_dump(by_alias=True)
    ])

    prediction = model.predict(input_data)[0]

    probability = model.predict_proba(input_data)[0][1]

    return {
        "prediction": int(prediction),
        "probability": round(float(probability), 4),
        "status": (
            "Money Laundering Detected"
            if prediction == 1
            else "Legitimate Transaction"
        )
    }

